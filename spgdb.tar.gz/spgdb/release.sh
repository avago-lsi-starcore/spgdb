#!/bin/sh

if [ $# -lt 1 ] ; then
	echo "usage: $0 release_dir [ arch ]*"
	exit 1
fi

release_dir=$1
score_dir=`basename ${release_dir}`
shift

remote_score_dir=$USER@planet1:~/score

while [ $# -gt 0 ] ; do
    case $1 in
	-s)
	    shift
	    remote_score_dir=$USER@$1:~/score
	    ;;
	*)
	    tmp_archs="${tmp_archs} $1"
	    ;;
    esac
    shift
done

archs=${tmp_archs:-WIN32 Linux Solaris}

remote_score_dir=$remote_score_dir/$score_dir

echo "release_dir:      ${release_dir}"
echo "score_dir:        $score_dir"
echo "remote_score_dir: $remote_score_dir"
echo

release_build.sh ${release_dir} ${archs}

if [ $? -eq 0 ] ; then
    echo

    for arch in ${archs} ; do
	echo Release ${arch}

	scp ${release_dir}/${arch}/zip/* ${remote_score_dir}_${arch}
	scp ${release_dir}/${arch}/ReadMe.txt ${remote_score_dir}_${arch}
    done
fi

