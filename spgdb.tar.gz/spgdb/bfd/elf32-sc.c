/** \file elf32-sc.c
 *  \brief Binary file descriptor elf32 functions for the StarCore architecture.
 *
 *	Copyright (c) 2006-2009 LSI Corporation Inc.
 *
 *	Copyright (c) 2006-2007 Agere Systems Inc.
 *
 *	Copyright (C) 1986, 1987, 1988, 1989, 1990, 1991, 1992, 1993, 1994, 1995,
 *	1996, 1997, 1998, 1999, 2000, 2001, 2002, 2003, 2004, 2005, 2007, 2008
 *	Free Software Foundation, Inc.
 *
 *	This file is part of BFD, the Binary File Descriptor library.
 *
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

#include "elf32-sc.h"

static reloc_howto_type *
sc_elf_reloc_name_lookup (bfd *abfd ATTRIBUTE_UNUSED, const char *r_name ATTRIBUTE_UNUSED)
{
    return NULL;
}

static reloc_howto_type *
sc_elf_reloc_type_lookup (bfd *abfd ATTRIBUTE_UNUSED, bfd_reloc_code_real_type code ATTRIBUTE_UNUSED)
{
    return NULL;
}

static bfd_boolean
_bfd_sc_elf_section_processing (bfd *abfd ATTRIBUTE_UNUSED, Elf_Internal_Shdr *hdr ATTRIBUTE_UNUSED)
{
    return TRUE;
}

static bfd_boolean
elf32_sc_section_flags (flagword *flags, const Elf_Internal_Shdr *hdr)
{
    if (hdr->sh_type == SHT_NOTE)
	*flags |= SEC_LINK_ONCE | SEC_LINK_DUPLICATES_SAME_CONTENTS;

    return TRUE;
}

#include "elf32-target.h"

