/** \file elf32-sc.h
 *  \brief 32-bit ELF support defines and function prototypes for the StarCore architecture.
 *
 *	Copyright (c) 2006-2009 LSI Corporation Inc.
 *
 *	Copyright (c) 2006-2007 Agere Systems Inc.
 *
 *	Copyright (C) 1986, 1987, 1988, 1989, 1990, 1991, 1992, 1993, 1994, 1995,
 *	1996, 1997, 1998, 1999, 2000, 2001, 2002, 2003, 2004, 2005, 2007, 2008
 *	Free Software Foundation, Inc.
 *
 *	This file is part of BFD, the Binary File Descriptor library.
 *
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

#include "bfd.h"
#include "sysdep.h"
#include "bfdlink.h"
#include "libbfd.h"
#include "elf-bfd.h"

extern const bfd_arch_info_type bfd_sc_arch;

#define	bfd_elf32_bfd_reloc_name_lookup sc_elf_reloc_name_lookup
#define	bfd_elf32_bfd_reloc_type_lookup sc_elf_reloc_type_lookup

#define	TARGET_LITTLE_SYM bfd_elf32_littlesc_vec
#define	TARGET_LITTLE_NAME "elf32-littlesc"

#define	TARGET_BIG_SYM bfd_elf32_bigsc_vec
#define	TARGET_BIG_NAME "elf32-bigsc"

#define	ELF_ARCH bfd_arch_sc
#define	ELF_MACHINE_CODE EM_STARCORE
#define	ELF_MAXPAGESIZE 0x8000

#define	elf_backend_section_processing _bfd_sc_elf_section_processing
#define	elf_backend_section_flags elf32_sc_section_flags

